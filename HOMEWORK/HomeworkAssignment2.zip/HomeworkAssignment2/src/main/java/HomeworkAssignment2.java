/*
Homework Assignment #2
My Fovorite Song
Title:You're Beautiful
Songwriter: James Blunt
*/
import java.lang.*;
public class HomeworkAssignment2 {
    public static void main(String[] args){
        String Song = "You're Beautiful";
        String Released = "18 May 2005";
        int YearOfBirth = 1974;
        String Genre = "Pop rock  "+"Soft rock"+"alternative rock";
        String Length = "3:32(album version),3:22(single edit)";
        String Label = "Atlantic "+" Custard";
        String Songwriter = "James Blunt "+" Sacha Skarbek"+" Amanda Ghost";
        String Producer = "Tom Rothrock";
        char   ProducerT ='T';
        float Duration = 3.32f;
        int    YOB = 2005;
        double  SqrtOfYOB = Math.sqrt(YOB);
        
        System.out.println("|=======================================================================|");
        System.out.println(" Released   "+Released+"                           ");
        System.out.println(" Genre      "+Genre+"                              ");
        System.out.println(" Length      "+Length+"                            ");
        System.out.println(" Label       "+Label+" ");
        System.out.println(" Songwriter  "+Songwriter+" ");
        System.out.println(" Producer    "+Producer+" ");        
        System.out.println(" ProducerT    "+ProducerT+" ");
        System.out.println(" Duration   "+Duration+" ");
        System.out.println(" Squar Root of the Year of Birth   "+SqrtOfYOB+" ");


        System.out.println("|======================================================================|");

     
        
    }    
}
